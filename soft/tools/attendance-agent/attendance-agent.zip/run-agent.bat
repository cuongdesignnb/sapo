@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM Load config
set CONFIG_FILE=%~dp0agent.config.bat
if not exist "%CONFIG_FILE%" (
  echo Config not found: %CONFIG_FILE%
  echo Copy agent.config.example.bat to agent.config.bat and edit it.
  exit /b 1
)
call "%CONFIG_FILE%"

REM Check PHP
where php >nul 2>nul
if errorlevel 1 (
  echo PHP not found in PATH. Please install PHP 8.2+ and add php.exe to PATH.
  exit /b 1
)

REM Check vendor
if not exist "%~dp0vendor\autoload.php" (
  echo vendor not found. Run: composer install
  exit /b 1
)

REM Validate config
if "%SERVER_URL%"=="" goto missing
if "%DEVICE_ID%"=="" goto missing
if "%DEVICE_IP%"=="" goto missing
if "%AGENT_SECRET%"=="" goto missing

REM Run agent
php "%~dp0agent.php" --server=%SERVER_URL% --device-id=%DEVICE_ID% --device-ip=%DEVICE_IP% --port=%DEVICE_PORT% --secret=%AGENT_SECRET% --timeout=%TIMEOUT%
exit /b %ERRORLEVEL%

:missing
echo Missing config values in agent.config.bat
exit /b 1
